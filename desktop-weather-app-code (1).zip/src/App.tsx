import { FormEvent, useEffect, useMemo, useState } from "react";

type WeatherResponse = {
  name: string;
  coord: { lat: number; lon: number };
  weather: Array<{ main: string; description: string }>;
  main: {
    temp: number;
    feels_like: number;
    humidity: number;
    pressure: number;
  };
  wind: { speed: number };
  visibility: number;
  timezone: number;
  sys: {
    sunrise: number;
    sunset: number;
  };
};

type ForecastResponse = {
  list: Array<{
    dt: number;
    main: { temp: number };
    pop: number;
  }>;
};

type AirResponse = {
  list: Array<{
    main: { aqi: number };
  }>;
};

const API_KEY = "639249c5a118501f1d93e96515f8c8af";
const baseUrl = "https://api.openweathermap.org/data/2.5";
const defaultCities = ["London", "Tokyo", "New York"];

function formatLocalTime(unixTime: number, timezoneOffset: number) {
  const date = new Date((unixTime + timezoneOffset) * 1000);
  const hours = String(date.getUTCHours()).padStart(2, "0");
  const minutes = String(date.getUTCMinutes()).padStart(2, "0");
  return `${hours}:${minutes}`;
}

function aqiLabel(aqi: number | null) {
  if (aqi === null) return "N/A";
  if (aqi === 1) return "Good";
  if (aqi === 2) return "Fair";
  if (aqi === 3) return "Moderate";
  if (aqi === 4) return "Poor";
  return "Very Poor";
}

export default function App() {
  const [selectedCity, setSelectedCity] = useState(defaultCities[0]);
  const [searchInput, setSearchInput] = useState("");
  const [weather, setWeather] = useState<WeatherResponse | null>(null);
  const [forecast, setForecast] = useState<ForecastResponse | null>(null);
  const [aqi, setAqi] = useState<number | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    let active = true;

    async function fetchWeather() {
      setLoading(true);
      setError(null);

      try {
        const weatherUrl = `${baseUrl}/weather?q=${encodeURIComponent(selectedCity)}&appid=${API_KEY}&units=metric`;
        const forecastUrl = `${baseUrl}/forecast?q=${encodeURIComponent(selectedCity)}&appid=${API_KEY}&units=metric`;

        const [weatherRes, forecastRes] = await Promise.all([fetch(weatherUrl), fetch(forecastUrl)]);

        if (!weatherRes.ok || !forecastRes.ok) {
          throw new Error("City not found or API limit reached.");
        }

        const weatherData = (await weatherRes.json()) as WeatherResponse;
        const forecastData = (await forecastRes.json()) as ForecastResponse;

        let airAqi: number | null = null;
        try {
          const airUrl = `${baseUrl}/air_pollution?lat=${weatherData.coord.lat}&lon=${weatherData.coord.lon}&appid=${API_KEY}`;
          const airRes = await fetch(airUrl);
          if (airRes.ok) {
            const airData = (await airRes.json()) as AirResponse;
            airAqi = airData.list[0]?.main.aqi ?? null;
          }
        } catch {
          airAqi = null;
        }

        if (active) {
          setWeather(weatherData);
          setForecast(forecastData);
          setAqi(airAqi);
        }
      } catch (err) {
        if (active) {
          setError(err instanceof Error ? err.message : "Unable to fetch weather data.");
        }
      } finally {
        if (active) {
          setLoading(false);
        }
      }
    }

    fetchWeather();

    return () => {
      active = false;
    };
  }, [selectedCity]);

  const hourlySnapshot = useMemo(() => {
    if (!forecast) return [];
    return forecast.list.slice(0, 5).map((entry) => {
      const time = new Date(entry.dt * 1000).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit", hour12: false });
      return `${time} ${Math.round(entry.main.temp)} C`;
    });
  }, [forecast]);

  const rainChance = useMemo(() => {
    if (!forecast) return 0;
    const upcoming = forecast.list.slice(0, 8);
    if (!upcoming.length) return 0;
    const peak = Math.max(...upcoming.map((entry) => entry.pop ?? 0));
    return Math.round(peak * 100);
  }, [forecast]);

  function handleCitySearch(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const cleaned = searchInput.trim();
    if (!cleaned) return;
    setSelectedCity(cleaned);
  }

  return (
    <main className="relative min-h-screen overflow-hidden bg-[url('/images/weather-clouds-hero.jpg')] bg-cover bg-center bg-fixed text-white">
      <div className="absolute inset-0 bg-sky-950/45" />

      <section className="relative min-h-screen overflow-hidden">

        <div className="relative z-10 mx-auto flex min-h-screen max-w-[1280px] flex-col px-8 pb-16 pt-8">
          <header className="mx-auto flex w-full max-w-[1120px] items-center gap-6">
            <div className="text-2xl font-semibold tracking-tight">Weather Astra</div>
            <nav className="flex flex-1 items-center justify-between rounded-full bg-white px-4 py-3 text-sm text-slate-900 shadow-lg shadow-black/10">
              <div className="flex items-center gap-6">
                <a className="font-medium" href="#">Dashboard</a>
                <a href="#">Forecast</a>
                <a href="#">Radar</a>
                <a href="#">Air Quality</a>
                <a href="#">Alerts</a>
              </div>
              <div className="rounded-full bg-sky-100 px-4 py-1 text-sky-800">Desktop App</div>
            </nav>
            <button className="rounded-full bg-orange-500 px-5 py-3 text-sm font-semibold transition hover:bg-orange-400">
              Sign in
            </button>
          </header>

          <div className="mx-auto flex w-full max-w-[1120px] flex-1 items-center justify-center">
            <div className="animate-rise-up max-w-3xl text-center">
              <p className="text-sm uppercase tracking-[0.28em] text-sky-100">Weather Astra</p>
              <h1 className="mt-6 text-6xl font-semibold leading-[1.05] tracking-tight text-white">
                Weather Insights Built For Desktop Decisions
              </h1>
              <p className="mx-auto mt-6 max-w-2xl text-lg text-sky-100">
                Real-time weather, rain alerts, wind trends, and air quality in one clean weather shower experience.
              </p>
              <div className="mt-10 flex justify-center gap-4">
                <button className="rounded-2xl bg-orange-500 px-8 py-4 text-lg font-semibold transition hover:scale-[1.02] hover:bg-orange-400">
                  Open Live Weather
                </button>
                <button className="rounded-2xl border border-white px-8 py-4 text-lg font-semibold transition hover:bg-white/10">
                  Explore Features
                </button>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className="relative z-10 px-8 py-16 text-slate-100">
        <div className="mx-auto max-w-[1120px]">
          <h2 className="text-3xl font-semibold tracking-tight">Important Weather Shower Features</h2>
          <p className="mt-2 max-w-3xl text-slate-400">
            Live OpenWeather API data powers this section. Switch or search cities to monitor core conditions.
          </p>

          <div className="mt-10 rounded-3xl border border-white/10 bg-slate-900/70 p-6">
            <div className="flex flex-wrap items-center gap-3">
              {defaultCities.map((city) => {
                const active = city === selectedCity;
                return (
                  <button
                    key={city}
                    onClick={() => setSelectedCity(city)}
                    className={`rounded-full px-5 py-2 text-sm transition ${
                      active ? "bg-sky-500 text-white" : "bg-white/10 text-slate-200 hover:bg-white/20"
                    }`}
                  >
                    {city}
                  </button>
                );
              })}
              <form onSubmit={handleCitySearch} className="ml-auto flex w-full gap-2 sm:w-auto">
                <input
                  value={searchInput}
                  onChange={(event) => setSearchInput(event.target.value)}
                  placeholder="Search city"
                  className="w-full rounded-full border border-white/20 bg-white/10 px-4 py-2 text-sm text-white placeholder:text-slate-300 focus:border-sky-400 focus:outline-none sm:w-56"
                />
                <button type="submit" className="rounded-full bg-orange-500 px-4 py-2 text-sm font-medium hover:bg-orange-400">
                  Load
                </button>
              </form>
            </div>

            <div className="mt-8 grid grid-cols-1 gap-10 lg:grid-cols-[1.3fr_1fr]">
              <div className="animate-float-slow">
                <p className="text-sm text-sky-300">Current weather in {weather?.name ?? selectedCity}</p>
                <p className="mt-2 text-6xl font-semibold">{loading ? "--" : `${Math.round(weather?.main.temp ?? 0)} C`}</p>
                <p className="mt-2 text-xl text-slate-300 capitalize">{weather?.weather[0]?.description ?? "Loading current conditions"}</p>
                <div className="mt-7 grid grid-cols-2 gap-x-8 gap-y-4 text-sm">
                  <p>Feels like: {loading ? "--" : `${Math.round(weather?.main.feels_like ?? 0)} C`}</p>
                  <p>Humidity: {loading ? "--" : `${weather?.main.humidity ?? 0}%`}</p>
                  <p>Wind: {loading ? "--" : `${Math.round((weather?.wind.speed ?? 0) * 3.6)} km/h`}</p>
                  <p>Rain chance: {loading ? "--" : `${rainChance}%`}</p>
                  <p>Pressure: {loading ? "--" : `${weather?.main.pressure ?? 0} hPa`}</p>
                  <p>Visibility: {loading ? "--" : `${((weather?.visibility ?? 0) / 1000).toFixed(1)} km`}</p>
                </div>
                {error ? <p className="mt-5 text-sm text-rose-300">{error}</p> : null}
              </div>

              <div className="space-y-6">
                <div>
                  <p className="text-sm text-slate-400">Today timeline</p>
                  <div className="mt-3 flex flex-wrap gap-2 text-xs text-slate-200">
                    {hourlySnapshot.map((item) => (
                      <span key={item} className="rounded-full bg-white/10 px-3 py-2">
                        {item}
                      </span>
                    ))}
                    {!hourlySnapshot.length ? <span className="rounded-full bg-white/10 px-3 py-2">Loading...</span> : null}
                  </div>
                </div>

                <div>
                  <div className="flex justify-between text-sm">
                    <span>Rain intensity</span>
                    <span>{loading ? "--" : `${rainChance}%`}</span>
                  </div>
                  <div className="mt-2 h-2 overflow-hidden rounded-full bg-white/15">
                    <div className="animate-bar-glide h-full rounded-full bg-sky-400" style={{ width: `${Math.max(rainChance, 6)}%` }} />
                  </div>
                </div>

                <div className="flex items-center justify-between text-sm text-slate-200">
                  <p>
                    Sunrise: {weather ? formatLocalTime(weather.sys.sunrise, weather.timezone) : "--:--"}
                  </p>
                  <p>
                    Sunset: {weather ? formatLocalTime(weather.sys.sunset, weather.timezone) : "--:--"}
                  </p>
                </div>

                <div className="rounded-2xl bg-white/10 px-4 py-3 text-sm">
                  <p>
                    Air quality index: {aqiLabel(aqi)} {aqi !== null ? `(AQI ${aqi}/5)` : ""}
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    </main>
  );
}
